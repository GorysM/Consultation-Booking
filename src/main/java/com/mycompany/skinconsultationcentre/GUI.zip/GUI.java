/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.skinconsultationcentre;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalTime;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import com.github.lgooddatepicker.components.DateTimePicker;
import java.awt.Dimension;
import javax.swing.JOptionPane;

/**
 *
 * @author Greg
 */
public class GUI extends JFrame {

    private JPanel doctorPanel;
    private JPanel consultationPanel;
    private JTable doctorTable;
    private JPanel selectedDoctorPanel;
    private JPanel patientPanel;
    private JLabel nameLab;
    private JLabel selNameLab;
    private JLabel surnameLab;
    private JLabel selSurnameLab;
    private JLabel numberLab;
    private JLabel selNumberLab;
    private JLabel specLab;
    private JLabel selSpecLab;
    private JLabel pHoursLab;
    private JLabel pUniqueIDLab;
    private JLabel pNameLab;
    private JLabel pSurnameLab;
    private JLabel pDobLab;
    private JLabel pMobileNLab;
    private JLabel pNotesLab;
    private JTextField pNameField;
    private JTextField pSurnameField;
    private JTextField pUniqueIDField;
    private JTextField pDobField;
    private JTextField pMobileNField;
    private JTextField pNotesField;
    private JTextField pHoursField;
    private JButton submitBut;
    private JPanel dayTimePanel;
    private JLabel dateTimeLab;
    private JLabel docIDLab;
    private JLabel selDocIDLab;
    

//    private ArrayList<Doctor> doctors;
    private WestminsterSkinConsultationManager manager;

    public GUI(WestminsterSkinConsultationManager manager_passed) {
        super("Add a consultation "); //titlos jframe
        super.setSize(950, 650); // 500H, 200V
        super.setResizable(false); // Kleidoma sto resizing apo user
//        doctors = manager.getDoctors();

        //create panels
        manager = manager_passed;
        dayTimePanel = new JPanel();
        doctorPanel = new JPanel();
        consultationPanel = new JPanel();
        selectedDoctorPanel = new JPanel();
        patientPanel = new JPanel();
//        doctorPanel.setBackground(Color.red);
//        consultationPanel.setBackground(Color.green);
//        selectedDoctorPanel.setBackground(Color.orange);
//        patientPanel.setBackground(Color.pink);

        super.setLayout(new GridLayout(1, 2));// 1 = row 2= columns
        super.add(doctorPanel);
        super.add(consultationPanel);

        DateTimePicker callendar = new DateTimePicker();
        dateTimeLab = new JLabel();
        dateTimeLab.setText("Date time picker: ");
        patientPanel.setLayout(new GridLayout(7, 2));
        submitBut = new JButton("Submit Booking");
//        submitBut.setSize(15, 5); 
        submitBut.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double timeCons;
                double timeCons2;
                String timeListCons[];
                int uniqueID;
                uniqueID = Integer.parseInt(selDocIDLab.getText());
                Consultation new_cons = new Consultation(callendar.getDatePicker().toString(), callendar.getTimePicker().toString(), Double.parseDouble(pHoursField.getText()), pNotesField.getText(), new Petient(Integer.parseInt(pUniqueIDField.getText()), pNameField.getText(), pSurnameField.getText(), pDobField.getText(), pMobileNField.getText()));
                timeListCons = new_cons.getTime().split(":");
                timeCons = Integer.parseInt(timeListCons[0]) + Integer.parseInt(timeListCons[1]) / 100.0;
                timeCons2 = timeCons + new_cons.getHours();
                System.out.println(new_cons);
                System.out.println(uniqueID);

                String time;
                String time_list[];
                double timeD;
                double timeD2;
                boolean availability = true;
                for (int i = 0; i < manager.getDoctors().size(); i++) {
                    if (manager.getDoctors().get(i).getMedicalLicenceNumber() == uniqueID) {
                        for (int j = 0; j < manager.getDoctors().get(i).getConsultationList().size(); j++) {
                            if (new_cons.getDate().equals(manager.getDoctors().get(i).getConsultationList().get(j).getDate())) {
                                time = manager.getDoctors().get(i).getConsultationList().get(j).getTime();
                                time_list = time.split(":");
                                timeD = Integer.parseInt(time_list[0]) + Integer.parseInt(time_list[1]) / 100.0;
                                timeD2 = timeD + manager.getDoctors().get(i).getConsultationList().get(j).getHours();
                                System.out.println(timeD + " " + timeD2 + " " + timeCons + " " + timeCons2 );
                                if (timeCons >= timeD && timeCons <= timeD2) {
                                    availability = false;
                                    break;
                                }
                                if (timeCons2 >= timeD && timeCons2 <= timeD2) {
                                    availability = false;
                                    break;
                                }

                            }

                        }

                    }
                    if (availability == true) {
                        manager.getDoctors().get(i).addConstultation(new_cons);
                        manager.saveInAFile();
                        JOptionPane.showConfirmDialog(null,"Your consultation now has been booked press ok to continue ", "Consultation confirmation", JOptionPane.DEFAULT_OPTION);
                        break;
                    } else {
                        boolean availability2 = true;
                        for (int k = 0; k < manager.getDoctors().size(); k++) {
                            if (manager.getDoctors().get(k).getMedicalLicenceNumber() != uniqueID && manager.getDoctors().get(i).getSpecilization().equals(manager.getDoctors().get(k).getSpecilization())) {
                                for (int t = 0; t < manager.getDoctors().get(k).getConsultationList().size(); t++) {
                                    if (new_cons.getDate().equals(manager.getDoctors().get(k).getConsultationList().get(t).getDate())) {
                                        time = manager.getDoctors().get(k).getConsultationList().get(t).getTime();
                                        time_list = time.split(":");
                                        timeD = Integer.parseInt(time_list[0]) + Integer.parseInt(time_list[1]) / 100.0;
                                        timeD2 = timeD + manager.getDoctors().get(k).getConsultationList().get(t).getHours();
                                        if (timeCons >= timeD && timeCons <= timeD2) {
                                            availability = false;
                                            break;
                                        }
                                        if (timeCons2 >= timeD && timeCons2 <= timeD2) {
                                            availability = false;
                                            break;
                                        }

                                    }

                                }

                            }

                        }
                    }
                }
            }
        });

        dayTimePanel.setLayout(new GridLayout(2, 1));
        dayTimePanel.add(dateTimeLab);
        dayTimePanel.add(callendar);
        consultationPanel.setLayout(new GridLayout(4, 1));
        consultationPanel.add(selectedDoctorPanel);
        consultationPanel.add(patientPanel);
        consultationPanel.add(dayTimePanel);
        consultationPanel.add(submitBut);
        String columns[] = {"surname", "name", "specilization", "mobileNumber"};
        doctorTable = new JTable();
        TableModel model;

        //fill the table
        Object[][] allData = new Object[manager.getDoctors().size()][columns.length];
        for (int i = 0; i < manager.getDoctors().size(); i++) {
            Object[] data = {manager.getDoctors().get(i).getSurname(), manager.getDoctors().get(i).getName(), manager.getDoctors().get(i).getSpecilization(), manager.getDoctors().get(i).getMobileNumber()};
            allData[i] = data;
        }
        model = new DefaultTableModel(allData, columns);
        doctorTable.setModel(model);
        doctorTable.getSelectionModel().addListSelectionListener(new RowSelectionListener());
        JScrollPane scrollPanel = new JScrollPane(doctorTable);
        doctorTable.setGridColor(Color.black);
        doctorPanel.add(scrollPanel);

        //fill selectedDoctorPanel
        nameLab = new JLabel();
        nameLab.setHorizontalAlignment(SwingConstants.RIGHT);
        surnameLab = new JLabel();
        surnameLab.setHorizontalAlignment(SwingConstants.RIGHT);
        numberLab = new JLabel();
        numberLab.setHorizontalAlignment(SwingConstants.RIGHT);
        specLab = new JLabel();
        specLab.setHorizontalAlignment(SwingConstants.RIGHT);
        selNameLab = new JLabel();
        selSurnameLab = new JLabel();
        selSpecLab = new JLabel();
        selNumberLab = new JLabel();
        docIDLab = new JLabel();
        docIDLab.setHorizontalAlignment(SwingConstants.RIGHT);
        selDocIDLab = new JLabel();
        nameLab.setText("Name: ");
        surnameLab.setText("Surname: ");
        numberLab.setText("Mobile Num: ");
        specLab.setText("Specilization: ");
        docIDLab.setText("Unique ID: ");
        selectedDoctorPanel.setLayout(new GridLayout(5, 2));
        selectedDoctorPanel.add(surnameLab);
        selectedDoctorPanel.add(selSurnameLab);
        selectedDoctorPanel.add(nameLab);
        selectedDoctorPanel.add(selNameLab);
        selectedDoctorPanel.add(specLab);
        selectedDoctorPanel.add(selSpecLab);
        selectedDoctorPanel.add(numberLab);
        selectedDoctorPanel.add(selNumberLab);
        selectedDoctorPanel.add(docIDLab);
        selectedDoctorPanel.add(selDocIDLab);

        //Fill patient panel
        pNameLab = new JLabel();
        pNameLab.setHorizontalAlignment(SwingConstants.RIGHT);
        pUniqueIDLab = new JLabel();
        pUniqueIDLab.setHorizontalAlignment(SwingConstants.RIGHT);
        pSurnameLab = new JLabel();
        pSurnameLab.setHorizontalAlignment(SwingConstants.RIGHT);
        pDobLab = new JLabel();
        pDobLab.setHorizontalAlignment(SwingConstants.RIGHT);
        pMobileNLab = new JLabel();
        pMobileNLab.setHorizontalAlignment(SwingConstants.RIGHT);
        pNotesLab = new JLabel();
        pNotesLab.setHorizontalAlignment(SwingConstants.RIGHT);
        pHoursLab = new JLabel();
        pHoursLab.setHorizontalAlignment(SwingConstants.RIGHT);
        pNameLab.setText("Name: ");
        pUniqueIDLab.setText("Unique ID: ");
        pSurnameLab.setText("Surname: ");
        pDobLab.setText("Date Of Birth: ");
        pMobileNLab.setText("Mobile Number: ");
        pNotesLab.setText("Notes: ");
        pHoursLab.setText("Hours: ");
        pNameField = new JTextField();
        pSurnameField = new JTextField();
        pUniqueIDField = new JTextField();
        pDobField = new JTextField();
        pMobileNField = new JTextField();
        pNotesField = new JTextField();
        pHoursField = new JTextField();
        patientPanel.add(pSurnameLab);
        patientPanel.add(pSurnameField);
        patientPanel.add(pNameLab);
        patientPanel.add(pNameField);
        patientPanel.add(pUniqueIDLab);
        patientPanel.add(pUniqueIDField);
        patientPanel.add(pMobileNLab);
        patientPanel.add(pMobileNField);
        patientPanel.add(pDobLab);
        patientPanel.add(pDobField);
        patientPanel.add(pNotesLab);
        patientPanel.add(pNotesField);
        patientPanel.add(pHoursLab);
        patientPanel.add(pHoursField);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //otan patithei to koumpi x na kleisei to programma Kai termatizei to programma
        setVisible(true);//emfanise to main frame
    }

    private class RowSelectionListener implements ListSelectionListener {

        @Override
        public void valueChanged(ListSelectionEvent e) {
            int selectRow = doctorTable.getSelectedRow();
            System.out.println(selectRow);
            System.out.println(manager.getDoctors().get(selectRow));
            selSurnameLab.setText(manager.getDoctors().get(selectRow).getSurname());
            selNameLab.setText(manager.getDoctors().get(selectRow).getName());
            selSpecLab.setText(manager.getDoctors().get(selectRow).getSpecilization());
            selNumberLab.setText(manager.getDoctors().get(selectRow).getMobileNumber());
            selDocIDLab.setText(Integer.toString(manager.getDoctors().get(selectRow).getMedicalLicenceNumber()));
        }

    }

}
